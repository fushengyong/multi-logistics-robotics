#include <ros/ros.h>
#include <move_base_msgs/MoveBaseAction.h>
#include <actionlib/client/simple_action_client.h>
#include <tf/transform_datatypes.h>
#include <bits/stdc++.h>
typedef actionlib::SimpleActionClient<move_base_msgs::MoveBaseAction>MoveBaseClient;
using namespace std;

int main(int argc,char** argv)
{
	if(argc<2){
		ROS_ERROR("You must specify leader robot id.");
		return -1;
	}

	char *robot_id=argv[1];
	ros::init(argc,argv,"send_goals");
	double goal_x1;
	double goal_y1;
	double goal_theta=0;
	double goal_x2;
	double goal_y2;
    ros::param::get("~goal_x1",goal_x1);
    ros::param::get("~goal_y1",goal_y1);
    ros::param::get("~goal_x2",goal_x2);
    ros::param::get("~goal_y2",goal_y2);
	string move_base_str="/robot_";
	move_base_str+=robot_id;
	move_base_str+="/move_base";
	string s="python /home/libliuis/catkin_ws/src/navigation_multi/robot1.py ";
	s+=robot_id;
    system(s.c_str());
	MoveBaseClient ac(move_base_str,true);

	ROS_INFO("Waiting for the move_base action server");
	ac.waitForServer(ros::Duration(5));

	ROS_INFO("Connected to move base server");

	move_base_msgs::MoveBaseGoal goal;
	goal.target_pose.header.frame_id="map";
	goal.target_pose.header.stamp=ros::Time::now();

	goal.target_pose.pose.position.x=goal_x1;
	goal.target_pose.pose.position.y=goal_y1;

	double radians=goal_theta*(M_PI/180);
	tf::Quaternion quaternion;
	quaternion=tf::createQuaternionFromYaw(radians);
	geometry_msgs::Quaternion qMsg;
	tf::quaternionTFToMsg(quaternion,qMsg);
	goal.target_pose.pose.orientation=qMsg;

	ROS_INFO("Sending goal to robot no. %s:x=%f,y=%f,theta=%f",robot_id,goal_x1,goal_y1,goal_theta);
	ac.sendGoal(goal);

	ac.waitForResult();
	if(ac.getState()==actionlib::SimpleClientGoalState::SUCCEEDED)
	{
	    goal.target_pose.pose.position.x=goal_x2;
	    goal.target_pose.pose.position.y=goal_y2;
	    ROS_INFO("Sending goal to robot no. %s:x=%f,y=%f,theta=%f",robot_id,goal_x2,goal_y2,goal_theta);
	    ac.sendGoal(goal);
	    ac.waitForResult();
	    if(ac.getState()==actionlib::SimpleClientGoalState::SUCCEEDED)
	    {
	    	s="python /home/libliuis/catkin_ws/src/navigation_multi/robot2.py ";
	        s+=robot_id;
            system(s.c_str());
            s="rosnode kill robot_";
            s+=robot_id;
            s+="/fake_localization";
            system(s.c_str());
            s="rosnode kill robot_";
            s+=robot_id;
            s+="/move_base_node";
            system(s.c_str());
            s="rosparam delete /robot_";
            s+=robot_id;
            system(s.c_str());
			ROS_INFO("The robot have reached the storage_rack!");
		}
		else
			ROS_INFO("The base failed for some reason");
	}
	else
		ROS_INFO("The base failed for some reason");

	return 0;
}




