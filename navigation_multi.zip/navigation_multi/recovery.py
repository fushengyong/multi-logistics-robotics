import os
import MySQLdb
import sys
x=(1.30,4.28,7.48,17.00,24.67,32.48,37.99,46.70,52.95,56.50,1.71,6.18,12.00,19.98,25.39,31.41,37.80,42.05,47.95,54.74,3.49,6.52,13.90,19.57,26.03,29.99,36.97,43.56,47.95,54.74)
y=(10.38,10.46,10.46,10.61,10.31,10.31,10.61,10.68,10.90,10.71,28.91,29.11,29.04,28.91,28.84,28.03,28.19,28.03,27.86,28.11,44.95,45.08,44.95,44.82,44.69,45.35,45.21,45.48,45.48,45.48)
conn=MySQLdb.connect(host='localhost',port=3306,user='root',passwd='zls680902',db='logistics',)
cur=conn.cursor(MySQLdb.cursors.DictCursor)
cur.execute("delete from package where srn>0")
cur.execute("update rackoccupation set opy=0 where id>0")
for i in range(len(x)):
	cur.execute("update robot set ocu=0,x="+str(x[i])+",y="+str(y[i])+" where id="+str(i))
cur.close()
conn.commit()
conn.close()