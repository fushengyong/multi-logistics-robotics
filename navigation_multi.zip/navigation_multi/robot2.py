import os
import MySQLdb
from sys import argv
scripts,robot_id=argv
conn=MySQLdb.connect(host='localhost',port=3306,user='root',passwd='zls680902',db='logistics',)
cur=conn.cursor(MySQLdb.cursors.DictCursor)
cur.execute("update robot set ocu = '0' where id ='"+str(robot_id)+"'")
cur.close()
conn.commit()
conn.close()