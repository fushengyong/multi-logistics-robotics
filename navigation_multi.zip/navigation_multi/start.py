import os
import time
import MySQLdb
import sys
import math
#the location of the storage_rack except the first one denotes the entrance of the warehouse
storage_rack_x=0
storage_rack_y=0
PID=20170001
entrance_x=[24.16,25.87,28.04,30.91,32.76]
entrance_y=[1.07,1.25,1.21,1.39,1.39]
os.system('gnome-terminal -e "bash -c \'roscore\'" &')
time.sleep(3)
os.system('gnome-terminal -e "bash -c \'roslaunch navigation_multi navigation_multi.launch\'" &')
time.sleep(6)
# os.system('gnome-terminal -e "bash -c \'roslaunch navigation_multi print_location.launch\'" &')
# conn=MySQLdb.connect(host='localhost',port=3306,user='root',passwd='zls680902',db='logistics',)
# cur=conn.cursor(MySQLdb.cursors.DictCursor)
#id->packageid srn->Storage_rack_number
# cur.execute("create table package(id varchar(30),srn int)")
# cur.execute("insert into package values('1','3')")
# cur.execute("insert into package values('2','11')")
# cur.execute("insert into package values('3','8')")
#p=packageID n=storage_rack_ID m=robot_ID
# cur.close()
# conn.commit()
# conn.close()
while True:
    command=input("Store package input 0  Take package input 1  Quit input 2:")
    if command==2:
    	break
    if command!=0 and command!=1 and command!=2:
        print "Command error!!!"
        continue
    if command==0:
    	conn=MySQLdb.connect(host='localhost',port=3306,user='root',passwd='zls680902',db='logistics',)
        cur=conn.cursor(MySQLdb.cursors.DictCursor)
        rack_size=cur.execute("select * from rackoccupation where opy = '0'")
        rack_rows=cur.fetchall()
        cur.close()
        conn.commit()
        conn.close()
        if rack_size==0:
            print "Sorry!!! There is no free space for your package!!!"
            continue
        else:
            print "Please wait for the nearest robot come to the entrance to carry your package!"
            conn=MySQLdb.connect(host='localhost',port=3306,user='root',passwd='zls680902',db='logistics',)
            cur=conn.cursor(MySQLdb.cursors.DictCursor)
            robot_free_number=cur.execute("select * from robot where ocu = '0'")
            robot_rows=cur.fetchall()
            if robot_free_number==0:
            	print "All robots are occupied,please wait!!!"
            	continue
            m=int(robot_rows[0]['id'])
            mindist=1000000.0
            for i in range(robot_free_number):
                temp=math.sqrt(math.pow((entrance_x[PID%5]-float(robot_rows[i]['x'])),2)+math.pow((entrance_y[PID%5]-float(robot_rows[i]['y'])),2))
                if mindist>temp:
                    mindist=temp
                    m=robot_rows[i]['id']
            os.system('gnome-terminal -e "bash -c \'roslaunch navigation_multi robot_'+str(m)+'.launch\'" &')
            time.sleep(5)
            print '\033[5;36;47m',
            print "Your service robot is robot_"+str(m)
            print '\033[0m',
            cur.execute("update rackoccupation set opy='1' where id='"+str(rack_rows[0]['id'])+"'")
            print '\033[1;31;40m',
            print "Your package ID is "+str(PID)
            print '\033[0m',
            cur.execute("insert into package values('"+str(PID)+"','"+str(rack_rows[0]['id'])+"')")
            t=cur.execute("select * from location where id='"+str(rack_rows[0]['id'])+"'")
            rows=cur.fetchall()
            cur.execute("update robot set x='"+str(rows[0]['x'])+"',y='"+str(rows[0]['y'])+"' where id='"+str(m)+"'")
            cur.close()
            conn.commit()
            conn.close()
            storage_rack_x=rows[0]['x']
            storage_rack_y=rows[0]['y']
            wi2='<group ns="robot_'+str(m)+'">\n'
            wi3='    <node pkg="navigation_multi" type="send_goal" respawn="false" name="send_goal" output="screen" args="'+str(m)+'">\n'
            wix1='     <param name="goal_x1" type="double" value="'+str(entrance_x[PID%5])+'" />\n'
            wiy1='    <param name="goal_y1" type="double" value="'+str(entrance_y[PID%5])+'" />\n'
            wix2='    <param name="goal_x2" type="double" value="'+str(storage_rack_x)+'" />\n'
            wiy2='    <param name="goal_y2" type="double" value="'+str(storage_rack_y)+'" />\n'
            f=open(r'/home/libliuis/catkin_ws/src/navigation_multi/launch/send_goals.launch')
            lines=f.readlines()
            f.close()
            lines[2]=wi2
            lines[3]=wi3
            lines[4]=wix1
            lines[5]=wiy1
            lines[6]=wix2
            lines[7]=wiy2
            f=open(r'/home/libliuis/catkin_ws/src/navigation_multi/launch/send_goals.launch','w')
            f.writelines(lines)
            f.close()
            os.system('gnome-terminal -e "bash -c \'roslaunch navigation_multi send_goals.launch\'" &')
            time.sleep(5)
            PID+=1
            if PID==20179999:
                print "PID has been used up!!!"
                break
    else:
        p=input("Show your package ID:")
        conn=MySQLdb.connect(host='localhost',port=3306,user='root',passwd='zls680902',db='logistics',)
        cur=conn.cursor(MySQLdb.cursors.DictCursor)
        t=cur.execute("select * from package where id='"+str(p)+"'")
        rows=cur.fetchall()
        if t==0:
            print "Package ID does not exist,please confirm your Package ID!"
            continue
        n=int(rows[0]['srn'])
        t=cur.execute("select * from location where id='"+str(n)+"'")
        rows=cur.fetchall()
        storage_rack_x=float(rows[0]['x'])
        storage_rack_y=float(rows[0]['y'])
        cur.execute("delete from package where id = '"+str(p)+"'")
        cur.close()
        conn.commit()
        conn.close()
        conn=MySQLdb.connect(host='localhost',port=3306,user='root',passwd='zls680902',db='logistics',)
        cur=conn.cursor(MySQLdb.cursors.DictCursor)
        robot_free_number=cur.execute("select * from robot where ocu = '0'")
        robot_rows=cur.fetchall()
        if robot_free_number==0:
            print "All robots are occupied,please wait!!!"
            continue
        m=int(robot_rows[0]['id'])
        mindist=1000000.0
        for i in range(robot_free_number):
            temp=math.sqrt(math.pow((storage_rack_x-float(robot_rows[i]['x'])),2)+math.pow((storage_rack_y-float(robot_rows[i]['y'])),2))
            if mindist>temp:
                mindist=temp
                m=robot_rows[i]['id']
        os.system('gnome-terminal -e "bash -c \'roslaunch navigation_multi robot_'+str(m)+'.launch\'" &')
        time.sleep(5)
        print '\033[5;36;47m',
        print "Your service robot is robot_"+str(m)
        print '\033[0m',
        cur.execute("update rackoccupation set opy='0' where id='"+str(n)+"'")
        cur.execute("update robot set x='"+str(entrance_x[PID%5])+"',y='"+str(entrance_y[PID%5])+"' where id='"+str(m)+"'")
        cur.close()
        conn.commit()
        conn.close()
        wi2='<group ns="robot_'+str(m)+'">\n'
        wi3='    <node pkg="navigation_multi" type="send_goal" respawn="false" name="send_goal" output="screen" args="'+str(m)+'">\n'
        wix1='     <param name="goal_x1" type="double" value="'+str(storage_rack_x)+'" />\n'
        wiy1='    <param name="goal_y1" type="double" value="'+str(storage_rack_y)+'" />\n'
        wix2='    <param name="goal_x2" type="double" value="'+str(entrance_x[PID%5])+'" />\n'
        wiy2='    <param name="goal_y2" type="double" value="'+str(entrance_y[PID%5])+'" />\n'
        f=open(r'/home/libliuis/catkin_ws/src/navigation_multi/launch/send_goals.launch')
        lines=f.readlines()
        f.close()
        lines[2]=wi2
        lines[3]=wi3
        lines[4]=wix1
        lines[5]=wiy1
        lines[6]=wix2
        lines[7]=wiy2
        f=open(r'/home/libliuis/catkin_ws/src/navigation_multi/launch/send_goals.launch','w')
        f.writelines(lines)
        f.close()
        os.system('gnome-terminal -e "bash -c \'roslaunch navigation_multi send_goals.launch\'" &')
        time.sleep(5)
os.system('python /home/libliuis/catkin_ws/src/navigation_multi/recovery.py')